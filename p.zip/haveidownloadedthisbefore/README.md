Have-I-Downloaded-This-Before
=============================

A Chrome extension that checks whether you've downloaded a file before

throw a "fuck" in there somewhere

three options for user:
  1)Resume
  2)Show in Folder
  3)Cancel download
